export { default } from './SelectTags';
