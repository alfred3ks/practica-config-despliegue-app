export { default } from './AdvertsPage';
