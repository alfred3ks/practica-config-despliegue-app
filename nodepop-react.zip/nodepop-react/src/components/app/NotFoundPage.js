function NotFoundPage() {
  return <div>404 | Ooops, page not found</div>;
}

export default NotFoundPage;
